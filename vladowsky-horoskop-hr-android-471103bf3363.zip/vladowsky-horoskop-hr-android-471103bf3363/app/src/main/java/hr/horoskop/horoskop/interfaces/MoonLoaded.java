package hr.horoskop.horoskop.interfaces;

import hr.horoskop.horoskop.model.HoroscopeFeed;
import hr.horoskop.horoskop.model.Moon;

/**
 * Created by Zoran on 24.7.2015..
 */
public interface MoonLoaded {
    public void onMoonLoaded(Moon moon);

}
