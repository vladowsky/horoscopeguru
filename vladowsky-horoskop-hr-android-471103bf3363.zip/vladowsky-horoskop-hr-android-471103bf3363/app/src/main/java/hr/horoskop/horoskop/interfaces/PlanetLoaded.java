package hr.horoskop.horoskop.interfaces;

import hr.horoskop.horoskop.model.PlanetFeed;

/**
 * Created by Zoran on 24.7.2015..
 */
public interface PlanetLoaded {
    public void onPlanetLoaded(PlanetFeed planetFeed);
}
