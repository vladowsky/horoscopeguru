package hr.horoskop.horoskop.interfaces;

import hr.horoskop.horoskop.model.HoroscopeFeed;

/**
 * Created by zoran on 23.09.2015..
 */
public interface YearHoroscopeLoaded {
    public void onYearHoroscopeLoaded(HoroscopeFeed horoscopeFeed);
}
