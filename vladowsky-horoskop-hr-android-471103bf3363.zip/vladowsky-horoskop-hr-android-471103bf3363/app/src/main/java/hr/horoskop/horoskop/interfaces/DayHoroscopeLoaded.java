package hr.horoskop.horoskop.interfaces;

import hr.horoskop.horoskop.model.HoroscopeFeed;

/**
 * Created by ZoPa on 23.4.2015..
 */
public interface DayHoroscopeLoaded {
    public void onDayHoroscopeLoaded(HoroscopeFeed dayHoroscopeFeed);
}
