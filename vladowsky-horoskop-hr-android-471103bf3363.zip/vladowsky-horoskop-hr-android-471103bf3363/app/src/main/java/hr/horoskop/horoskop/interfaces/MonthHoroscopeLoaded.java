package hr.horoskop.horoskop.interfaces;

import hr.horoskop.horoskop.model.HoroscopeFeed;

/**
 * Created by ZoPa on 24.4.2015..
 */
public interface MonthHoroscopeLoaded {
    public void onMonthHoroscopeLoaded(HoroscopeFeed monthHoroscopeFeed);
}
